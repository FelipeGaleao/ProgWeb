# Atividade 02

Na aula deste tópico foi apresentado o JavaScript, uma linguagem de script para ser executada em navegadores. <br>

Neste tópico, foi apresentada a sintaxe básica da linguagem, eventos e o modelo de dados de documentos (DOM). <br>
Em um dos exemplos, foi apresentado uma forma de mudar a cor de um elemento, contudo o mesmo não restaurava a cor anterior quando o mouse sai do elemento. <br>

Nesta atividade, você deverá tratar o evento de saída do mouse do quadrado de forma a restaurar a cor original usando JavaScript (o código original pode ser acessado pelos slides). <br>
Assim, nesta atividade você deverá submeter pelo menos dois arquivos, um arquivo HTML e um arquivo JS com a resposta para a atividade. Você pode, ou não, usar CSS nesta atividade. <br>


